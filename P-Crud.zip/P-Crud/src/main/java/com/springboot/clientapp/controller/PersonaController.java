package com.springboot.clientapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springboot.clientapp.models.entity.Domicilio;
import com.springboot.clientapp.models.entity.Persona;
import com.springboot.clientapp.models.service.IDomicilioService;
import com.springboot.clientapp.models.service.IPersonaService;

@Controller
@RequestMapping("/views/personas")
public class PersonaController {
	@Autowired
	private IPersonaService personaService;
	
	@Autowired
	private IDomicilioService domicilioService;
	
	@GetMapping("/")
	public String listarPersonas(Model model) {
		List<Persona> listadoPersonas = personaService.listarTodos();
		
		model.addAttribute("titulo", "Lista de personas");
		model.addAttribute("personas", listadoPersonas);
		return "/views/personas/listar";
	}
	
	@GetMapping("/create")
	public String crear(Model model) {
		Persona persona = new Persona();
		List<Domicilio> listDomicilio =  domicilioService.listaDomicilio();
		model.addAttribute("titulo", "Formulario: nueva persona");	
		model.addAttribute("persona", persona);
		model.addAttribute("domicilio", listDomicilio);
		return "/views/personas/frmCrear";
	}
	
	@PostMapping("/save")
	public String guardar(@ModelAttribute Persona persona ) {
		personaService.guardar(persona);
		System.out.print("Cliente guardado exitosamente");
		return "redirect:/views/personas/";
	}
	
	@GetMapping("/edit/{id}")
	public String editar(@PathVariable("DNI") Long dni, Model model) {
		Persona persona = new personaService.buscarPorId(dni);
		List<Domicilio> listDomicilio =  domicilioService.listaDomicilio();
		model.addAttribute("titulo", "Formulario: editar persona");	
		model.addAttribute("persona", persona);
		model.addAttribute("domicilio", listDomicilio);
		return "/views/personas/frmCrear";
	}
	
	@GetMapping("/delete/{id}")
	public String eliminar(@PathVariable("DNI") Long dni) {
		personaService.eliminar(dni);
		System.out.printl("Registro eliminado exitosamente");
		return "redirect:/views/personas/";
	}
}
