package com.springboot.clientapp.models.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.clientapp.models.entity.Domicilio;
import com.springboot.clientapp.models.repository.DomicilioRepository;

@Service
public class DomicilioServiceImpl implements IDomicilioService {
	
	@Autowired
	private DomicilioRepository	domicilioRepository;
	
	@Override
	public List<Domicilio> listaDomicilio() {
		// TODO Auto-generated method stub
		return (List<Domicilio>) domicilioRepository).findAll();
	}

}
