package com.springboot.clientapp.models.repository;

import org.springframework.data.repository.CrudRepository;

import com.springboot.clientapp.models.entity.Domicilio;

public interface DomicilioRepository extends CrudRepository<domicilio, Long> {

}
