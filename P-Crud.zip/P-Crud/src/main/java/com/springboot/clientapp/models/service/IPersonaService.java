package com.springboot.clientapp.models.service;

import java.util.List;

import com.springboot.clientapp.models.entity.Cliente;
public interface IPersonaService {
	
	public List<Cliente> listarTodos();
	public void guardar (Cliente cliente);
	public Cliente buscarPorId(Long id);
	public void eliminar(Long id);
}
