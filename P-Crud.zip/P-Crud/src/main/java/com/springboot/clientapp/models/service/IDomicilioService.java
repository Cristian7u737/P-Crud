package com.springboot.clientapp.models.service;

import java.util.List;

import com.springboot.clientapp.models.entity.Domicilio;

public interface IDomicilioService {
	
	List<Domicilio> listaDomicilio(); 
}
