package com.springboot.clientapp.models.repository;

import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.springboot.clientapp.models.entity.Persona;

@Repository
public interface PersonaRepository extends CrudRepository<Persona, Long>{

}
