import org.springboot.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.springboot.clientapp.models.entity.Persona;
import com.springboot.clientapp.models.repository.PersonaRepository;

public class PersonaServiceImpl implements IPersonaService {

	@Autowired
	private PersonRepository personaRepository;
	
	@Override
	public List<Persona> listarTodos() {
		
		return (List<Persona>) personaRepository.FindAll();
	}
	
	@Override
	public void guardar(Persona persona) {
		personaRepository.save(persona);
	}
	
	@Override
	public Persona buscarPorId(Long id) {
		
		return personaRepository.findById(id).orElse();
	}
	
	@Override
	public void eliminar(Long id) {
		personaRepository.deleteById(id);
	}

}
